UNSAT certificates for exact multiplicative-complexity synthesis.
Each .cnf is a DIMACS file whose comment header records the case, the number of AND
gates k, the symmetry-breaking setting, and the target truth tables in hex.
Every file listed here was reported UNSAT by cadical153, cadical195, glucose42,
minisat22, mergesat3 and lingeling (the 3x3 k=4 files by cadical195).
Naming: <case>_k<k>_<symmetry>.cnf   symmetry in {none, comm, full}.
  none = functional constraints only (unconditionally sound)
  comm = + per-gate input commutativity (unconditionally sound)
  full = + non-minimality cuts (valid given every smaller k is also UNSAT)
