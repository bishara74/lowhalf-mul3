k=5 case CNFs for the 3x3 low-half product mod 8 (DIMACS; comment header gives case and options).
certs_k5/N_k5_lam<l>.cnf          main normalization (gate0=b0*a0, canonical bases, order break, sigma, cuts)
certs_k5/N_nocuts_k5_lam<l>.cnf   same without non-minimality cuts (self-contained: no reliance on MC>4)
certs_k5/N_nosigma_k5_lam<l>.cnf  without operand-swap break
certs_k5/N_nofix_k5_lam<l>.cnf    without gate-0 first-entry fixing
certs_k5/N_comm_k5_lam<l>.cnf     plain commutativity instead of canonical bases, no sigma (lam=1 not decided; not used)
cases/k5_lam<l>.cnf               identical in content to N_k5_lam<l>.cnf (written by run_cases.py)
All decided instances are UNSAT; see k5_all_runs.csv. Generator: mc_norm.py; soundness: SOUNDNESS.md.
